# Mōno Template Audit-First Pack

Use this pack to stop random visual guessing and force Codex to reverse-engineer the public visual/behavior spec of:

https://monof-template.webflow.io/

Important legal rule:
- Do not copy proprietary Webflow source code into the final project.
- Do not copy paid template assets into the final project.
- Use public HTML/CSS/JS only to understand layout, tokens, animations, breakpoints, and behavior.
- Rebuild with original React + Tailwind + Framer Motion code and Sahil Kumar content.

Recommended flow:
1. Upload this pack into `/Users/sahilkumar/Desktop/mono_templet`.
2. Paste `codex-prompts/01_STOP_AND_AUDIT_FIRST.md`.
3. Let Codex create actual `reference-audit/*.md` files using live inspection, public HTML/CSS/JS, and screenshots.
4. Review the audit.
5. Paste `codex-prompts/02_IMPLEMENT_FROM_AUDIT_ONLY.md`.
6. Do not continue random polishing.
