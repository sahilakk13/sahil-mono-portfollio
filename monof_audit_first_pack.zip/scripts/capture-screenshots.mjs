/**
 * Optional Playwright screenshot script.
 * Install if needed:
 *   npm i -D playwright
 *   npx playwright install chromium
 *
 * Run:
 *   node scripts/capture-screenshots.mjs
 */
import fs from "node:fs/promises";
import { chromium } from "playwright";

const widths = [1440, 1280, 1024, 768, 430, 390];
const reference = "https://monof-template.webflow.io/";
const current = "http://localhost:5173/";

await fs.mkdir("reference-screenshots", { recursive: true });
await fs.mkdir("current-screenshots", { recursive: true });

const browser = await chromium.launch();
for (const width of widths) {
  const page = await browser.newPage({ viewport: { width, height: 1200 }, deviceScaleFactor: 1 });
  await page.goto(reference, { waitUntil: "networkidle" });
  await page.screenshot({ path: `reference-screenshots/home-${width}.png`, fullPage: true });
  await page.goto(current, { waitUntil: "networkidle" });
  await page.screenshot({ path: `current-screenshots/home-${width}.png`, fullPage: true });
  await page.close();
}
await browser.close();
console.log("Screenshots captured.");
