/**
 * Run locally inside Codex project if Node internet access is available:
 *   node scripts/extract-reference.mjs
 *
 * This downloads public HTML and attempts to list CSS/JS/image URLs for analysis.
 * It does not copy assets into the final React app.
 */
import fs from "node:fs/promises";
import path from "node:path";

const root = "https://monof-template.webflow.io/";
const outDir = "reference/monof";
await fs.mkdir(outDir, { recursive: true });

async function fetchText(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`${res.status} ${url}`);
  return await res.text();
}

const html = await fetchText(root);
await fs.writeFile(path.join(outDir, "home.html"), html);

const urls = new Set();
const attrRe = /\b(?:href|src)=["']([^"']+)["']/g;
let m;
while ((m = attrRe.exec(html))) {
  const raw = m[1];
  if (raw.startsWith("#") || raw.startsWith("mailto:") || raw.startsWith("tel:")) continue;
  try {
    urls.add(new URL(raw, root).href);
  } catch {}
}

const css = [...urls].filter(u => u.includes(".css"));
const js = [...urls].filter(u => u.includes(".js"));
const images = [...urls].filter(u => /\.(png|jpg|jpeg|webp|gif|svg)(\?|$)/i.test(u));

await fs.writeFile(path.join(outDir, "asset-urls.json"), JSON.stringify({ css, js, images, all: [...urls] }, null, 2));

for (const [type, list] of [["css", css], ["js", js]]) {
  await fs.mkdir(path.join(outDir, type), { recursive: true });
  for (const url of list) {
    try {
      const text = await fetchText(url);
      const name = path.basename(new URL(url).pathname) || `${type}.txt`;
      await fs.writeFile(path.join(outDir, type, name), text);
    } catch (e) {
      console.warn("failed", url, e.message);
    }
  }
}

console.log(`Saved ${css.length} CSS, ${js.length} JS, ${images.length} image URLs to ${outDir}`);
