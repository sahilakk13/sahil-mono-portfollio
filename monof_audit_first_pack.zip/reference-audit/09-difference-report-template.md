# 09 — Difference Report Template

Codex must fill this with actual findings from reference/current screenshot comparison.

For each section:

## Header
Reference:
Current:
Difference:
Exact fix:
Files:

## Hero
Reference:
Current:
Difference:
Exact fix:
Files:

## Partners
Reference:
Current:
Difference:
Exact fix:
Files:

## Work
Reference:
Current:
Difference:
Exact fix:
Files:

## About
Reference:
Current:
Difference:
Exact fix:
Files:

## Feature Grid / Vision
Reference:
Current:
Difference:
Exact fix:
Files:

## Services
Reference:
Current:
Difference:
Exact fix:
Files:

## Showreel
Reference:
Current:
Difference:
Exact fix:
Files:

## Pricing
Reference:
Current:
Difference:
Exact fix:
Files:

## FAQ
Reference:
Current:
Difference:
Exact fix:
Files:

## Testimonials
Reference:
Current:
Difference:
Exact fix:
Files:

## Stats
Reference:
Current:
Difference:
Exact fix:
Files:

## Success Story
Reference:
Current:
Difference:
Exact fix:
Files:

## Blog
Reference:
Current:
Difference:
Exact fix:
Files:

## Contact/Footer
Reference:
Current:
Difference:
Exact fix:
Files:

## Cursor / Overlay / Z-index
Reference:
Current:
Difference:
Exact fix:
Files:
