# 02 — Layout Map

This file should be refined by Codex after live inspection/screenshots.

## Global observed structure
The homepage is not a normal vertical landing page. It behaves like an editorial Webflow template with:
- top navigation and bottom/page navigation elements
- huge display typography
- strong section boundaries
- full-width off-white and dark sections
- heavy use of image/collage blocks
- multi-card feature grids
- interactive service rows
- dense footer and page-layout promo block

## Layout principles to rebuild
- Do not center every section.
- Use wide max-width containers close to 1440px.
- Use thin divider/hairline grid systems.
- Use huge heading blocks with tight line-height.
- Use 2-column editorial grids on desktop.
- Use staggered project card offsets.
- Use dark transition bands/curves only where reference uses them.
- Use bottom nav safely so it does not cover content.

## Section layout requirements

### Header
- Minimal horizontal nav.
- Brand left.
- Page links center/right.
- CTA link/button.
- Thin divider or transparent overlay behavior.
- Should not compete visually with bottom nav.

### Hero
- Upper grid with service list and intro copy.
- Large title block: brand + role/title.
- Visual image/collage strip after/under title.
- Scroll indicator/meta.
- Strong use of hairlines/dots.
- Must avoid accidental clipping.

### Partners
- Dense logo wall, likely 16 logos.
- Label/date row.
- Tight grid rhythm.

### Work
- Reference has 4 projects, but Sahil can use 6.
- Desktop should use large editorial cards, not small generic cards.
- Card media should have premium composition.
- Project title/meta placement must be minimal.

### About
- Label row + huge headline.
- Stat blocks.
- One main image/media block.
- Strong asymmetrical split.

### Feature grid
- 2x2/mixed cards.
- Pricing transparency, performance boost, chat/live collaboration, and dark vision text transition.
- The dark transition is not just empty; text placement must feel deliberate.

### Services
- Large indexed rows.
- Each row has index, title, image/preview, and description in reference.
- Avoid generic tab layout.
- All rows should remain visible.
- Active/hover state must be subtle.

### Showreel
- Large 16:9 video embed/card.
- Heading directly above.
- Strong radius/crop.

### Pricing
- Huge stacked heading left.
- Pricing cards right/below depending viewport.
- Cards tall with list details.

### FAQ
- Large row height.
- Number/index, question, answer, plus/minus control.
- Strong divider rhythm.

### Testimonials
- Image/media + large quote.
- Number controls 01-04 /04.
- Slider not generic carousel.

### Stats
- Large heading + CTA.
- Metric cards paired with proof/testimonial cards.
- Avoid identical repeated placeholder cards.

### Success story
- Image pair + quote block.
- Editorial, not blank.

### Blog
- Row list with date and title.
- Hover movement.

### Contact/Footer
- Contact CTA with form/link.
- Dense newsletter/footer layout.
- Bottom/page layout preview section may exist after footer; if implemented, must not look like accidental footer overlap.
