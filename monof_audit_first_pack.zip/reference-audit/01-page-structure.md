# 01 — Page Structure Audit

Reference: https://monof-template.webflow.io/

Source visible from public homepage output:
- Header/navigation
- Hero
- Angled/visual media strip after hero
- Partners/logo wall
- Work/portfolio preview
- About/who-we-are
- Mixed feature card grid
- Dark "Built Different / Vision" transition
- Services list
- Showreel video
- Pricing
- FAQ + "Looking for more?"
- Testimonials slider
- Stats cards
- Success story quote
- Blog preview
- Contact CTA
- Newsletter/footer
- Bottom navigation/page layout promo blocks

## Exact visible homepage content order

### 1. Header
Visible navigation:
- Mōno™ Studio
- Home
- Studio
- Work (4)
- News
- Contact
- Talk to Denis / Get in touch / Schedule a call link

### 2. Hero
Left service/category list:
- Web Design
- Social Media
- Marketing
- Development
- SEO Optimization

Hero body:
> No cookie cutter sites. No empty claims. Only practical tools and smart strategies that drive growth and build brands.

CTA:
- Let's talk

Meta:
- © 2026 Mōno™ Studio
- Mōno™
- Studio
- Scroll Down

### 3. Media/image strip
The parsed page exposes many images immediately after hero. This indicates a strong visual collage/strip, likely with angled or overlapping media.

### 4. Partners
Label:
- (Partners)
- 2011-26©

Logo wall:
- 16 visible image/logo items

### 5. Work
Label:
- (Portfolio 26©)

Heading:
- Work(4)

CTA:
- View all work

Project cards:
- Forma Digital 26 ©
- One Step 24 ©
- Nero Vision 25 ©
- Bold Moves 24 ©

### 6. About
Label:
- (Who we are)
- Mōno™ Studio

Heading:
- We shape brands with focus, intention, and impact.

Stats:
- +13
- team members
- across the
- World

Image/media card:
- One main image

### 7. Feature grid
Cards/content:
- (Team of experts) +9 Mōno™
- Pricing with complete transparency
- (Performance Boost) Page speed +78%, Bounce rate -13%, View pricing
- (Live collaboration), Today 17:01/17:02 chat card
- Built Different
- Design with purpose
- Code with passion
- Create with vision
- Innovate always
- (Our Vision)
- (Scroll for more)

### 8. Services
Label:
- (Services)

CTA:
- Get started

Services:
- (001) Web Design — image + description
- (002) Social Media — image + description
- (003) Development — image + description
- (004) Brand Identity — image + description
- (005) Marketing — image + description

### 9. Showreel
Heading:
- Showreel 26©

Video:
- YouTube embed: https://www.youtube.com/watch?v=677IU_NErto
- iframe size in embed data: 940x528

### 10. Pricing
Label:
- (Pricing)

Heading:
- Pick Smart.
- Pay Less.
- Build Better.

Copy:
- Choose the plan that fits you best.

Cards:
Starter:
- $2,000 / Project
- Tailored website layouts
- Core SEO configuration
- Mobile-first responsive design
- Brand-ready UI framework
- Ideal for new launches and rebrands
- Timeline: 1-2 weeks
- Book a call

Growth:
- $4,000 / Project
- High-end design with smooth interactions
- Complete on-site SEO setup
- Adaptive layouts for every screen
- CMS setup for content or case studies
- Performance tuning & optimization
- Timeline: 2-3 weeks
- Book a call

### 11. FAQ
Label:
- (FAQ)

Items:
01 What services does your agency offer?
02 How do you determine the right strategy?
03 How long does a typical project take?
04 Do you work with businesses in any industry?

Additional CTA:
- (Looking for more?)
- Expand your scope with marketing, SEO, or content creation.
- Contact us

### 12. Testimonials
Label:
- (Testimonials)

Slides:
- John Doe, Head design at Circle®
- Amantha Doe, Founder of Radius®
- Max Trump, Founder of Light Studio®
- Camila Verga, Head design at LogoIspum®

Controls:
- 01
- 02
- 03
- 04
- /04
- (Scroll for more)

### 13. Stats
Label:
- (Stats)

Heading:
- Mōno™ stands behind the data.

Copy:
- Our success is reflected in the numbers we achieve for our clients...

CTA:
- Let's talk

Stats:
- (Value created) $174M
- (Return client rate) 92%
- (Projects delivered) +320
- (Client retention) 88%

Each stat pairs with testimonial/evidence cards containing:
- CRI metric delta
- star rating
- quote
- name

### 14. Success stories
Images appear before label.
Label:
- (Success stories)

Quote:
> Mōno™ helped us simplify complexity...

Person:
- Elena Rossi
- Marketing Director at Auralis®

### 15. Blog
Label:
- (Blog)

Heading:
- Smart insights.

CTA:
- See all

Posts:
- November 11, 2025 — The power of simplicity in modern real brand design
- October 1, 2025 — From idea to execution: building products that last
- October 3, 2026 — Why great brands are built on clarity, not complexity
- October 4, 2025 — Designing digital systems that scale your business

### 16. Contact
Label:
- (Contact us)

Heading:
- Let's talk.

Form states:
- Thank you! Your submission has been received!
- Oops! Something went wrong while submitting the form.
- By contacting us, you accept our Terms and Privacy Policy.

CTA card/link:
- Crafting visuals. Shaping stories. Let’s create great work together!
- Let’s Collaborate

### 17. Footer / newsletter
Brand:
- Mōno™ Studio

Newsletter:
- (Newsletter)
- Be the first to know what’s new.
- No noise. Just curated updates.

Footer meta:
- © 2026 Mōno™ Studio - Powered by Webflow

Page links:
- Home
- Studio
- Licensing
- Work I
- Work II
- Work III
- Blog I
- Blog II
- Blog III
- Contact I
- Contact II
- Contact III

Contact:
- contact@monostudio.io
- (+1) 930 046 720
- info@monostudio.io

Location:
- Roc Boronat 112, Floor 3 - Door 2 (08018) Barcelona, Spain

Social:
- social icon/image links

### 18. Bottom/page layout preview promo
Visible after footer:
- Home / Work (4)
- Mōno™
- Studio / Contact
- View Work
- Read more
- Page Layouts
- links to Home, Studio, Work 1/2/3, Work Page, Blog 1/2/3, Blog Page, Contact 1/2/3, 401, 404
- Get Template
- Unlock 420+ Templates

## Sahil content mapping
Keep structure but map:
- Mōno™ Studio → Sahil Kumar™
- Web Design / Social Media / Marketing / Development / SEO Optimization → Web Design / Data Analytics / Dashboard Design / Development / SEO Optimization
- Work cards → EdMaxEx, BudgetBites, H&M BI Analytics, AI Try-On System, LeadPilot, Portfolio Website
- Agency stats → Sahil/project metrics
- Contact/footer details → Sahil's portfolio contact details
