# 05 — Animation & Interaction Map

This is the highest-priority file. Codex must refine by live inspection.

## Required categories

### Page load / hero
- Header/nav appears cleanly.
- Hero text/list reveal likely staggered.
- Massive title may have mask-like/upward reveal.
- Media/collage may reveal with clip/scale.
- Hairlines/dots may appear with width/opacity animation.

### Scroll reveals
- Webflow-like reveal: opacity + y transform + possibly clip/mask.
- Avoid generic fade-only.
- Stagger cards/children.
- Timing should be polished and fast enough.

Suggested Framer Motion:
```ts
export const easeOutExpo = [0.22, 1, 0.36, 1];

export const reveal = {
  hidden: { opacity: 0, y: 42, filter: "blur(8px)" },
  show: { opacity: 1, y: 0, filter: "blur(0px)", transition: { duration: 0.85, ease: easeOutExpo } }
};

export const stagger = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08, delayChildren: 0.05 } }
};
```

### Navigation
- Template exposes normal top nav and additional bottom/page navigation elements near the bottom.
- If bottom nav is used as floating nav, it must not fight top header.
- Header must stay minimal and not cover content.

### Custom cursor
Only if the reference clearly uses one.
- Desktop only.
- Default state subtle.
- Expands on interactive elements.
- Labels: View, Open, Close, Read only where needed.
- Must not look like a bug.

### Work card hover
- Media scale.
- Card lift.
- Meta/title micro-move.
- Cursor label likely “View”.
- Hover should feel smooth, not bouncy.

### Services
Reference public content shows each service row contains:
- index
- title
- image
- description
Therefore implementation should not hide inactive rows like a tab-only component.
Interaction should preserve full list visibility.

### Showreel
- Video card may have hover/play affordance.
- Keep large 16:9 embed ratio based on public embed 940x528.

### FAQ
- Smooth open/close.
- Plus/minus icon rotate or switch.
- Row divider and hover state.
- Accessible `aria-expanded`.

### Testimonials
- Slider controls 01 02 03 04 /04.
- Active state.
- Smooth crossfade/slide.
- Quote/image transition.

### Footer/page layout promo
- Footer is dense.
- There are additional page-layout preview links after footer in the public page output.
- Any floating navigation must hide/fade or safe-space before footer if it covers content.
