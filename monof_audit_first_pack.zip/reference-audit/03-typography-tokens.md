# 03 — Typography Tokens

Codex must refine exact values from CSS inspection.

## Known/likely
The template uses a large geometric sans-serif look similar to Inter/Satoshi/Neue Montreal.
For our build:
- Use Inter as base if exact font cannot be legally embedded.
- Do not ship paid font files.
- Use CSS clamp for huge titles.

## Target scales

### Hero title
- Very large, near viewport-width scale.
- Tight line-height around 0.82–0.9.
- Heavy font weight.
- Negative letter spacing.
- May intentionally crop at edges but must not accidentally cut required letters.

### Section headings
- Large editorial scale.
- Tight line-height.
- Strong negative tracking.
- Mixed with small labels in parentheses.

### Labels
- Parenthesized labels: `(Partners)`, `(Portfolio 26©)`, `(Services)`.
- Small, clean, slightly muted.
- Often used with date/year/copyright marker.

### Body copy
- Compact but readable.
- Use muted gray for secondary copy.
- Line-height around 1.35–1.55.

### Cards
- Titles large but not generic.
- Meta text compact.
- CTA text inside black pill.

## Implementation tokens
Use CSS variables/classes:
- `.display-xl`
- `.section-title`
- `.section-label`
- `.body-large`
- `.body-small`
- `.meta`
- `.button-text`

Codex must inspect actual CSS to improve:
- exact font-family stack
- hero font-size at 1440/1280/1024
- section title sizes
- label sizes
- body sizes
- letter-spacing
