# 04 — Colors / Radius / Shadows

Codex must refine with extracted CSS, but these are close operating tokens.

## Colors
- Off-white page background
- Near-black text
- Charcoal/dark section background
- Muted gray secondary text
- Pale gray divider lines
- White/surface cards
- Black pill buttons

Suggested tokens:
```css
:root {
  --bg: #f7f7f4;
  --surface: #ffffff;
  --surface-muted: #f0f0eb;
  --text: #080808;
  --text-inverse: #f7f7f4;
  --muted: #777777;
  --line: #e6e6e1;
  --dark: #080808;
  --dark-soft: #111111;
  --button: #050505;
  --button-text: #ffffff;
  --radius-sm: 12px;
  --radius-md: 20px;
  --radius-lg: 32px;
  --radius-xl: 44px;
  --radius-pill: 999px;
  --shadow-soft: 0 20px 60px rgba(0,0,0,.12);
}
```

## Radius
- Large rounded media cards.
- Pill buttons.
- Footer/contact cards may have large radius.
- Video embed rounded.

## Borders / dividers
- Thin 1px hairlines.
- Dividers should appear structural, not decorative.
- Use throughout hero grid, service rows, FAQ rows, footer.

## Shadows
- Mostly subtle.
- Buttons may use blur/heavy shadow in hover states.
- Cards rely more on shape/space than heavy shadow.
