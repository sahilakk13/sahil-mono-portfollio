# 08 — Implementation Plan From Audit

## Stop random polishing
The implementation must be driven by extracted reference facts:
- page structure
- layout map
- typography tokens
- animation map
- responsive map
- difference report

## Priority implementation order
1. Navigation architecture
   - Decide top vs bottom nav behavior based on reference.
   - Prevent nav overlap.

2. Hero
   - Rebuild exact hero section structure.
   - Ensure service list, intro, CTA, meta, title, and media strip match reference rhythm.

3. Partners
   - Dense 16-card logo wall.

4. Work
   - Reference has 4; Sahil can have 6 but must retain same card grammar.
   - Use editorial media compositions, not generic geometric blocks.

5. About
   - Label + huge heading + stats + image split.

6. Feature grid / dark transition
   - 2x2 cards then vision/dark transition.
   - Avoid empty black block.

7. Services
   - Keep all rows visible.
   - Row structure: index / huge title / image / description.
   - Do not turn into generic tabs.

8. Showreel
   - Use 16:9, large rounded video block.

9. Pricing / FAQ / Testimonials / Stats
   - Make row/card proportions and controls match reference.

10. Contact/footer/page-layout promo
   - Avoid floating CTA bugs.
   - Avoid bottom nav overlap.
   - Keep dense structure.

11. Responsive
   - Implement from 07-responsive-map.

## Files likely to change
- `src/components/Header.tsx`
- `src/components/Hero.tsx`
- `src/components/LogoWall.tsx`
- `src/components/WorkPreview.tsx`
- `src/components/ProjectCard.tsx`
- `src/components/AboutPreview.tsx`
- `src/components/FeatureGrid.tsx`
- `src/components/ServicesShowcase.tsx`
- `src/components/Showreel.tsx`
- `src/components/Pricing.tsx`
- `src/components/FAQ.tsx`
- `src/components/Testimonials.tsx`
- `src/components/Stats.tsx`
- `src/components/SuccessStory.tsx`
- `src/components/BlogPreview.tsx`
- `src/components/ContactCTA.tsx`
- `src/components/Footer.tsx`
- `src/components/CustomCursor.tsx`
- `src/styles/globals.css`
- `src/styles/tokens.css`
- `src/lib/motion.ts`
