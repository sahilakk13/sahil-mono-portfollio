# 07 — Responsive Map

Codex must inspect exact behavior at:
- 1440
- 1280
- 1024
- 768
- 430
- 390

## General expected responsive behavior
- Desktop: editorial asymmetrical grids.
- Tablet: reduced columns, some two-column sections.
- Mobile: one-column flow.
- Hero title uses clamp; no horizontal overflow.
- Services rows remain readable and tappable.
- Work grid stacks.
- Header/mobile nav changes.
- Footer becomes stacked but remains dense.

## Critical mobile checks
- No horizontal scrolling.
- No fixed nav covering content.
- No huge title clipping except intentional.
- Contact/footer CTAs must not float accidentally.
- Custom cursor disabled.
- Touch targets >=44px.

## Codex task
Use Playwright screenshots and compare reference/current at same breakpoints before implementing responsive fixes.
