# 06 — Assets Inventory

Public homepage text output shows many image links with IDs. Exact URLs/dimensions must be extracted by Codex using HTML/CSS inspection.

## Visible image groups from parsed homepage

### Header/preload images
- Images IDs 26, 27, 28 near header/body start

### Hero/media strip images
- IDs 29–48 appear after hero section

### Partners/logo wall
- IDs 49–64, likely 16 partner logos

### About
- ID 65 main image

### Feature/live collaboration
- IDs 66, 67, 68

### Services
- IDs 69–73, one per service

### Testimonials
- IDs 74–77, one per testimonial

### Stats/proof cards
- IDs 78–81, one per proof/testimonial card

### Success story
- IDs 82–83

### Footer contact/social/icons
- IDs 84–89

### Page layout/footer preview
- IDs 90–100

## Legal handling
Do not copy final template assets into our project unless licensed.
Use them for:
- understanding composition
- aspect ratio
- cropping
- density
- media placement
- grayscale/monochrome treatment

Final build should use:
- original Sahil media
- placeholder original SVG compositions
- or licensed/free assets with similar composition
