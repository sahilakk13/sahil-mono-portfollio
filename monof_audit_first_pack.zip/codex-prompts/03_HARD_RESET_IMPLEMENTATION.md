Hard reset the implementation strategy.

The current site still feels custom. Replace section structures with audit-based structures instead of polishing.

For each component:
1. Read its reference audit section.
2. Compare current JSX/CSS.
3. Rewrite the structure if necessary.
4. Keep Sahil content.
5. Preserve original code ownership.
6. Run build.

Do not keep a custom section just because it looks good. If it differs from the reference, restructure it.

Start with:
- Header/nav
- Hero
- Work
- Services
- Feature grid/dark transition
- Footer/nav overlap

Then continue remaining sections.
