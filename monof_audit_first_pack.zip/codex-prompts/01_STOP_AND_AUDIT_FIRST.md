Stop current implementation direction.

We are wasting time because the current implementation is being polished by guesswork instead of being rebuilt from the reference template’s actual public structure and behavior.

Reference:
https://monof-template.webflow.io/

Important legal rule:
Do not copy proprietary Webflow source code into the final React project.
Do not copy paid assets into the final project.
Do not reuse Webflow class names as our app architecture.
But you may inspect publicly loaded HTML/CSS/JS/assets to understand exact layout, tokens, animation behavior, breakpoints, interaction logic, and asset composition.

New workflow:
Do not code portfolio changes yet.
First create a complete reference audit.

Create these folders:
- reference/monof/
- reference-audit/
- reference-screenshots/
- current-screenshots/

Inspect/download for analysis only:
- homepage HTML
- public CSS files
- public JS files
- image/asset URLs
- Webflow interaction data if present
- route pages
- responsive screenshots

Use commands if available:
```bash
mkdir -p reference/monof reference-audit reference-screenshots current-screenshots
curl -L https://monof-template.webflow.io/ -o reference/monof/home.html
```

If possible, use Playwright to capture screenshots of reference and current site at:
- 1440
- 1280
- 1024
- 768
- 430
- 390

Also inspect:
https://monof-template.webflow.io/
https://monof-template.webflow.io/studio
https://monof-template.webflow.io/work/work-1
https://monof-template.webflow.io/work/work-2
https://monof-template.webflow.io/work/work-3
https://monof-template.webflow.io/contact/contact-1
https://monof-template.webflow.io/contact/contact-2
https://monof-template.webflow.io/contact/contact-3
https://monof-template.webflow.io/blog/blog-1
https://monof-template.webflow.io/blog/blog-2
https://monof-template.webflow.io/blog/blog-3

Create/fill these files:
- reference-audit/01-page-structure.md
- reference-audit/02-layout-map.md
- reference-audit/03-typography-tokens.md
- reference-audit/04-color-border-radius-shadow-tokens.md
- reference-audit/05-animation-and-interaction-map.md
- reference-audit/06-assets-inventory.md
- reference-audit/07-responsive-map.md
- reference-audit/08-implementation-plan-from-audit.md
- reference-audit/09-difference-report.md

The most important file is:
reference-audit/05-animation-and-interaction-map.md

Document:
- page load animation
- hero reveal
- text reveals
- scroll-triggered motion
- sticky/top/bottom nav behavior
- card hover behavior
- services interaction
- FAQ animation
- testimonial slider
- cursor behavior
- footer/page layout preview behavior
- responsive menu behavior

Do not say “close enough.”
Do not continue random polishing.
Do not start implementation until the audit and difference report are complete.

Stop after the audit files are created and report where they are.
