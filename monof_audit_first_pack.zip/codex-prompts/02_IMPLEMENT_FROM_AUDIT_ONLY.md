Now implement from the audit only.

Source of truth:
- reference-audit/01-page-structure.md
- reference-audit/02-layout-map.md
- reference-audit/03-typography-tokens.md
- reference-audit/04-color-border-radius-shadow-tokens.md
- reference-audit/05-animation-and-interaction-map.md
- reference-audit/06-assets-inventory.md
- reference-audit/07-responsive-map.md
- reference-audit/08-implementation-plan-from-audit.md
- reference-audit/09-difference-report.md

Do not guess.
Do not invent.
Do not keep polishing the old custom direction.
Refactor the React/Tailwind/Framer implementation section by section to match the audit.

Priority:
1. Navigation behavior
2. Hero layout/animation
3. Partners density
4. Work card proportions/hover
5. About layout
6. Feature grid + dark transition
7. Services rows/interactions
8. Showreel/pricing/FAQ
9. Testimonials/stats/success story
10. Contact/footer/page-layout promo
11. Cursor behavior
12. Responsive behavior

Rules:
- Keep Sahil Kumar content.
- Use original React code.
- Do not copy proprietary Webflow source/assets.
- Do not make generic Tailwind sections.
- Do not add new random sections.
- Run `npm run build` after changes.
- Fix all errors.

After implementation, create:
reference-audit/10-final-match-report.md

In that file list:
- each section
- what now matches
- remaining mismatch
- files changed
- reason if any mismatch cannot be fully matched without original paid Webflow export/assets

Do not say done until build passes.
